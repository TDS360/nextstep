export const placeholderData = {
    location: {
        name: "Kolkata, West Bengal, India",
        lat: 22.5744,
        lng: 88.3629,

    }
}